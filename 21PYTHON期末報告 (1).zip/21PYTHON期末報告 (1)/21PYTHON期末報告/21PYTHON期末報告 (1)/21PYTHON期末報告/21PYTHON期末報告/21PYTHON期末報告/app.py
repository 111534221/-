from flask import Flask, render_template, request, jsonify, redirect, url_for, make_response, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash  # 新增加密工具
from datetime import datetime
import pandas as pd
import io
import random
import os
from urllib.parse import quote

app = Flask(__name__)

# --- 重要：Session 加密密鑰 (必須有這個才能使用登入與收藏功能) ---
app.secret_key = 'uv_insight_pro_secure_key_2025' 

# --- 1. 資料庫設定 ---
basedir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(basedir, 'uv_monitor.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- 2. 資料模型 ---

# UV 觀測紀錄表 (保留原本)
class UVRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    site = db.Column(db.String(50), nullable=False)
    uvi = db.Column(db.Float, nullable=False)
    time = db.Column(db.DateTime, default=datetime.now)

# 使用者系統 (升級：密碼長度增加到 200 以容納加密後的字串)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False) 
    role = db.Column(db.String(20), default='user') # 'admin' 或 'user'
    # 關聯收藏夾
    favorites = db.relationship('Favorite', backref='user', lazy=True)

# 新增：收藏站點模型
class Favorite(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    site_name = db.Column(db.String(50), nullable=False)

# 判定勞安風險等級的工具函式 (保留原本)
def get_uv_info(uvi):
    if uvi < 3: return {"level": "低量級", "color": "#10b981", "advice": "不需防護", "burn": "60分鐘"}
    if uvi < 6: return {"level": "中量級", "color": "#facc15", "advice": "需遮陽帽/防曬", "burn": "30-40分鐘"}
    if uvi < 8: return {"level": "高量級", "color": "#fb923c", "advice": "穿長袖/戴墨鏡", "burn": "20-30分鐘"}
    if uvi < 11: return {"level": "甚高量級", "color": "#ef4444", "advice": "減少戶外活動", "burn": "15-20分鐘"}
    return {"level": "危險級", "color": "#7e22ce", "advice": "禁止長時曝曬", "burn": "10-15分鐘"}

# --- 3. 資料庫初始化 ---

def seed_data():
    # 建立預設數據
    db.session.query(UVRecord).delete()
    db.session.query(User).delete() # 初始化時清除舊帳號
    
    all_sites = ['基隆', '臺北', '新北', '桃園', '新竹縣', '新竹市', '苗栗', '台中', '彰化', '南投', '雲林', '嘉義縣', '嘉義市', '臺南', '高雄', '屏東', '宜蘭', '花蓮', '臺東', '澎湖', '金門', '馬祖']
    today_str = datetime.now().strftime("%Y-%m-%d")
    
    for s in all_sites:
        for h in range(8, 18): 
            base_uv = 2.0 + (5.0 - abs(13-h)) * 1.5
            db.session.add(UVRecord(
                site=s, 
                uvi=round(max(0, base_uv + random.uniform(-1, 1)), 1), 
                time=datetime.strptime(f"{today_str} {h:02d}:00", "%Y-%m-%d %H:%M")
            ))
    
    # 建立加密版預設管理員帳號 (密碼: 1234)
    admin_pw = generate_password_hash('1234')
    db.session.add(User(username='admin', password=admin_pw, role='admin'))
    
    # 建立加密版測試使用者 (密碼: password)
    test_pw = generate_password_hash('password')
    db.session.add(User(username='testuser', password=test_pw, role='user'))
        
    db.session.commit()

with app.app_context():
    db.create_all()
    if not UVRecord.query.first():
        seed_data()

# --- 4. 登入/註冊路由 (升級為雜湊加密版) ---

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    if not username or not password:
        return jsonify({"success": False, "msg": "帳號密碼不可為空"}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({"success": False, "msg": "帳號已存在"}), 400
    
    try:
        # 使用 generate_password_hash 進行加密
        hashed_pw = generate_password_hash(password)
        new_user = User(username=username, password=hashed_pw, role='user')
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"success": True, "msg": "註冊成功，請登入"})
    except Exception as e:
        return jsonify({"success": False, "msg": f"註冊失敗：{str(e)}"}), 500

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    user = User.query.filter_by(username=username).first()
    
    # 使用 check_password_hash 驗證雜湊值
    if user and check_password_hash(user.password, password):
        session["logged_in"] = True
        session["user_id"] = user.id
        session["username"] = user.username
        session["role"] = user.role 
        return jsonify({"success": True, "msg": "登入成功", "role": user.role})
    
    return jsonify({"success": False, "msg": "帳號或密碼錯誤"}), 401

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# --- 5. 新增：個人收藏 API ---

@app.route("/api/favorite", methods=["POST"])
def toggle_favorite():
    if not session.get("logged_in"):
        return jsonify({"success": False, "msg": "請先登入"}), 401
    
    data = request.get_json()
    site = data.get('site')
    user_id = session.get('user_id')
    
    fav = Favorite.query.filter_by(user_id=user_id, site_name=site).first()
    if fav:
        db.session.delete(fav)
        status = "removed"
    else:
        new_fav = Favorite(user_id=user_id, site_name=site)
        db.session.add(new_fav)
        status = "added"
    
    db.session.commit()
    return jsonify({"success": True, "status": status})

# --- 6. 核心顯示路由 (加入收藏資訊) ---

@app.route("/", methods=["GET", "POST"])
def index():
    all_sites = [r.site for r in db.session.query(UVRecord.site).distinct().all()]
    selected_site = request.form.get("site") or request.args.get("site")
    comp_site = request.form.get("comp_site")
    
    analysis = None
    main_data = []
    comp_data = []
    user_favorites = []
    is_favorite = False

    # 獲取當前使用者的收藏清單
    if session.get("logged_in"):
        favs = Favorite.query.filter_by(user_id=session.get('user_id')).all()
        user_favorites = [f.site_name for f in favs]

    if selected_site:
        main_data = UVRecord.query.filter_by(site=selected_site).order_by(UVRecord.time).all()
        if main_data:
            latest = main_data[-1]
            max_rec = max(main_data, key=lambda x: x.uvi)
            analysis = {
                "current_uvi": latest.uvi,
                "info": get_uv_info(latest.uvi),
                "max_uvi": max_rec.uvi,
                "max_time": max_rec.time.strftime("%H:%M")
            }
            # 判斷目前選擇的站點是否在收藏中
            is_favorite = selected_site in user_favorites
    
    if comp_site:
        comp_data = UVRecord.query.filter_by(site=comp_site).order_by(UVRecord.time).all()

    return render_template("index.html", 
                           sites=all_sites, 
                           selected_site=selected_site, 
                           analysis=analysis, 
                           main_data=main_data, 
                           comp_site=comp_site, 
                           comp_data=comp_data,
                           user_favorites=user_favorites,
                           is_favorite=is_favorite)

# --- 7. 管理員專用 API (保留原本邏輯) ---

@app.route("/api/records", methods=["POST"])
def add_record_api():
    if session.get("role") != 'admin': 
        return jsonify({"msg": "需要管理員權限"}), 403
    
    data = request.get_json()
    new_rec = UVRecord(site=data['site'], uvi=data['uvi'], time=datetime.now())
    db.session.add(new_rec)
    db.session.commit()
    return jsonify({"success": True})

@app.route("/update/<int:id>", methods=["POST"])
def update_record(id):
    if session.get("role") != 'admin': 
        return "權限不足，僅限管理員執行", 403
    
    record = UVRecord.query.get_or_404(id)
    try:
        new_uvi = float(request.form.get("new_uvi"))
        record.uvi = new_uvi
        db.session.commit()
        return redirect(url_for('index', site=record.site))
    except:
        return "更新失敗", 400

@app.route("/delete/<int:id>", methods=["POST"])
def delete_record(id):
    if session.get("role") != 'admin': 
        return "權限不足，僅限管理員執行", 403
    
    record = UVRecord.query.get_or_404(id)
    site_name = record.site
    db.session.delete(record)
    db.session.commit()
    return redirect(url_for('index', site=site_name))

@app.route("/reset_db", methods=["POST"])
def reset_db():
    if session.get("role") != 'admin': 
        return "權限不足", 403
    seed_data()
    return redirect(url_for('index', site='臺北'))

# --- 8. 工具路由 (保留原本邏輯) ---

@app.route("/export/<site>")
def export(site):
    records = UVRecord.query.filter_by(site=site).all()
    if not records: return "無數據", 404
    df = pd.DataFrame([{"時間": r.time.strftime("%Y-%m-%d %H:%M"), "紫外線指數": r.uvi} for r in records])
    output = io.StringIO()
    df.to_csv(output, index=False, encoding='utf-8-sig') 
    response = make_response(output.getvalue())
    filename = quote(f"{site}_UV監測報告.csv")
    response.headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{filename}"
    return response

@app.route("/api/live_uv/<site>")
def live_uv(site):
    return jsonify({
        "time": datetime.now().strftime("%H:%M:%S"),
        "uvi": round(random.uniform(2, 12), 1),
        "cauv": round(random.uniform(3, 11), 1)
    })

if __name__ == "__main__":
    app.run(debug=True)